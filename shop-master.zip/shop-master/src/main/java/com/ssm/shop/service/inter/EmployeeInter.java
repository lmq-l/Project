package com.ssm.shop.service.inter;


import com.ssm.shop.pojo.Employee;

import java.util.List;

public interface EmployeeInter {
    List<Employee> listEmployee(Employee employee);
}
