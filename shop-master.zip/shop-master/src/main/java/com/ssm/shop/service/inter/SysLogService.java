package com.ssm.shop.service.inter;


import com.ssm.shop.pojo.SysLog;
import com.ssm.shop.service.CurdService;

/**
 * 日志管理
 * @author Louis
 * @date Oct 29, 2018
 */
public interface SysLogService extends CurdService<SysLog> {

}
