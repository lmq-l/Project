package com.ssm.shop.util;


import com.ssm.shop.pojo.*;

/**
 * 代码生成工具
 * ClassName: BeanUtilTest 
 * @Description: TODO
 * @author micoMo
 * @date 2017-9-16
 */
public class BeanUtilTest {

	public static void main(String[] args) throws Exception{
		BeanUtil.createCodeTool(PmsBanner.class);

	}
	
}
